﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Encuesta
{
    public partial class AdminUsers : Form
    {
        private string usuarioCuenta;
        private string totalRespuestas;

        public AdminUsers(string cuenta)
        {
            InitializeComponent();
            CargarUsuarios();
            usuarioCuenta = cuenta;
            CargarDatos();
        }

        private void AdminUsers_Load(object sender, EventArgs e)
        {
            CargarDatos();
            comboBox1.Items.Clear();
            comboBox1.Items.Add("1. Administrador");
            comboBox1.Items.Add("2. Usuario");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Este evento se maneja al seleccionar un rango en el ComboBox.
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                Usuario usuarioSeleccionado = (Usuario)listBox1.SelectedItem;

                // Seleccionar el rango actual del usuario en el ComboBox.
                if (usuarioSeleccionado.Rango == 1)
                {
                    comboBox1.SelectedIndex = 0;
                }
                else if (usuarioSeleccionado.Rango == 2)
                {
                    comboBox1.SelectedIndex = 1;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null || comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor, seleccione un usuario y un rango para actualizar.","Actualizar Rango");
                return;
            }

            Usuario usuarioSeleccionado = (Usuario)listBox1.SelectedItem;
            int nuevoRango = comboBox1.SelectedIndex + 1; // Índice 0 -> Rango 1, Índice 1 -> Rango 2

            // Verificar si el cambio de rango es válido
            if (usuarioSeleccionado.Rango == 1 && nuevoRango == 2 && !HayAlMenosOtroAdministrador(usuarioSeleccionado.Id))
            {
                MessageBox.Show("Debe haber al menos un administrador en el sistema.","Advertencia");
                return;
            }

            ActualizarRangoUsuario(usuarioSeleccionado.Id, nuevoRango);
        }

        private void ActualizarRangoUsuario(int idUsuario, int nuevoRango)
        {
            try
            {
                string query = "UPDATE Usuario SET Rango = @rango WHERE id_usuario = @idUsuario";
                using (SqlCommand command = new SqlCommand(query, Conexionbd.GetConnection()))
                {
                    command.Parameters.AddWithValue("@rango", nuevoRango);
                    command.Parameters.AddWithValue("@idUsuario", idUsuario);

                    int filasAfectadas = command.ExecuteNonQuery();
                    if (filasAfectadas > 0)
                    {
                        MessageBox.Show("Rango actualizado correctamente.","Actualizar Rango");
                        CargarUsuarios(); // Refrescar el ListBox
                    }
                    else
                    {
                        MessageBox.Show("No se pudo actualizar el rango.","Actualizar Rango");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar el rango: " + ex.Message,"Actualizar Rango");
            }
        }

        private bool HayAlMenosOtroAdministrador(int idUsuarioExcluido)
        {
            try
            {
                string query = "SELECT COUNT(*) FROM Usuario WHERE Rango = 1 AND id_usuario != @idUsuarioExcluido";
                using (SqlCommand command = new SqlCommand(query, Conexionbd.GetConnection()))
                {
                    command.Parameters.AddWithValue("@idUsuarioExcluido", idUsuarioExcluido);
                    int cantidadAdministradores = (int)command.ExecuteScalar();
                    return cantidadAdministradores > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al verificar administradores: " + ex.Message,"Vaya, que complcia'o");
                return false;
            }
        }

        // Método para cargar los datos en el DataGridView
        private void CargarDatos()
        {
            // Crear una tabla de datos para el DataGridView
            DataTable dt = new DataTable();
            dt.Columns.Add("Cuenta");
            dt.Columns.Add("Suma Total de Respuestas");

            // Obtener la lista de todos los usuarios con sus sumas de respuestas
            List<UsuarioConRespuestas> usuariosConRespuestas = ObtenerUsuariosConRespuestas();

            // Agregar los datos al DataTable
            foreach (var usuario in usuariosConRespuestas)
            {
                DataRow row = dt.NewRow();
                row["Cuenta"] = usuario.Cuenta;
                row["Suma Total de Respuestas"] = usuario.TotalRespuestas;
                dt.Rows.Add(row);
            }

            // Asignar los datos al DataGridView
            dataGridView1.DataSource = dt;
        }

        // Obtener los usuarios con la suma de sus respuestas
        private List<UsuarioConRespuestas> ObtenerUsuariosConRespuestas()
        {
            List<UsuarioConRespuestas> usuariosConRespuestas = new List<UsuarioConRespuestas>();

            try
            {
                string query = @"
            SELECT 
                u.Cuenta, 
                COALESCE(SUM(r.respuesta), 0) AS SumaRespuestas
            FROM 
                Usuario u
            LEFT JOIN categorias c ON c.id_usuario = u.id_usuario
            LEFT JOIN preguntas p ON p.id_categoria = c.id
            LEFT JOIN respuestas r ON r.id_pregunta = p.id
            GROUP BY u.Cuenta";

                using (SqlCommand command = new SqlCommand(query, Conexionbd.GetConnection()))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            UsuarioConRespuestas usuario = new UsuarioConRespuestas
                            {
                                Cuenta = reader["Cuenta"].ToString(),
                                TotalRespuestas = reader["SumaRespuestas"] != DBNull.Value
                                    ? Convert.ToInt32(reader["SumaRespuestas"])
                                    : 0
                            };
                            usuariosConRespuestas.Add(usuario);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener usuarios con respuestas: " + ex.Message);
            }

            return usuariosConRespuestas;
        }

        private void CargarUsuarios()
        {
            try
            {
                string query = "SELECT id_usuario, Rango, Cuenta FROM Usuario";
                using (SqlCommand command = new SqlCommand(query, Conexionbd.GetConnection()))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        listBox1.Items.Clear();
                        while (reader.Read())
                        {
                            Usuario usuario = new Usuario
                            {
                                Id = Convert.ToInt32(reader["id_usuario"]),
                                Rango = Convert.ToInt32(reader["Rango"]),
                                Cuenta = reader["Cuenta"].ToString()
                            };
                            listBox1.Items.Add(usuario);
                        }
                        reader.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los usuarios: " + ex.Message,"Carga Usuarios");
            }
        }

        public class Usuario
        {
            public int Id { get; set; }
            public string Cuenta { get; set; }
            public int Rango { get; set; }

            public override string ToString()
            {
                return $"{Cuenta} (Rango: {(Rango == 1 ? "Administrador" : "Usuario")})";
            }
        }

        public class UsuarioConRespuestas
        {
            public string Cuenta { get; set; }
            public int TotalRespuestas { get; set; }
        }
    }
}
