﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Encuesta
{
    public partial class PreguntasCalGen : Form
    {
        private int preguntaActualIndex = 0; // Índice de la pregunta actual
        private int totalPreguntas = 0;
        private string cuentaUsuario; // Cuenta del usuario que inició sesión

        public PreguntasCalGen(string cuenta)
        {
            InitializeComponent();
            cuentaUsuario = cuenta; // Guardar la cuenta del usuario
            CargarPreguntas();
            
        }

        private void CargarPreguntas()
        {
            string query = "SELECT COUNT(*) FROM preguntas";

            using (SqlCommand cmd = new SqlCommand(query, Conexionbd.GetConnection()))
            {
                totalPreguntas = (int)cmd.ExecuteScalar();
            }

            if (totalPreguntas > 0)
            {
                MostrarPregunta();
            }
            else
            {
                MessageBox.Show("No hay preguntas disponibles.");
                button1.Enabled = false;
            }
        }

        private void MostrarPregunta()
        {
            if (preguntaActualIndex < totalPreguntas)
            {
                string query = "SELECT preguntas.pregunta, categorias.nombre AS Categoria " +
                               "FROM preguntas " +
                               "INNER JOIN categorias ON preguntas.id_categoria = categorias.id " +
                               "ORDER BY preguntas.id " +
                               "OFFSET @index ROWS FETCH NEXT 1 ROWS ONLY";

                using (SqlCommand cmd = new SqlCommand(query, Conexionbd.GetConnection()))
                {
                    cmd.Parameters.AddWithValue("@index", preguntaActualIndex);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            P.Text = reader["pregunta"].ToString();
                            Categoria.Text = reader["Categoria"].ToString();
                        }
                    }
                }

                comboBox1.Enabled = true;
                button1.Enabled = true;
            }
            else
            {
                P.Text = "Ya no hay más preguntas.";
                Categoria.Text = "";
                comboBox1.Enabled = false;
                button1.Enabled = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex != -1)
            {
                GuardarRespuestaEnBD();
                preguntaActualIndex++;
                comboBox1.SelectedIndex = -1; // Limpiar selección
                MostrarPregunta();
            }
            else
            {
                MessageBox.Show("Debe seleccionar una opción antes de continuar.","Selección");
            }
        }

        private void GuardarRespuestaEnBD()
        {
            int valor = comboBox1.SelectedIndex switch
            {
                0 => 5,
                1 => 4,
                2 => 3,
                3 => 2,
                4 => 1,
                _ => 0
            };

            string query = @"
        INSERT INTO respuestas (id_pregunta, respuesta)
        VALUES ((SELECT id FROM preguntas WHERE id_categoria IN (SELECT id_categoria FROM categorias WHERE id_usuario = (SELECT id_usuario FROM Usuario WHERE Cuenta = @cuenta))
                 ORDER BY id OFFSET @index ROWS FETCH NEXT 1 ROWS ONLY), @respuesta)";

            using (SqlCommand cmd = new SqlCommand(query, Conexionbd.GetConnection()))
            {
                cmd.Parameters.AddWithValue("@index", preguntaActualIndex);
                cmd.Parameters.AddWithValue("@respuesta", valor);
                cmd.Parameters.AddWithValue("@cuenta", cuentaUsuario);
                cmd.ExecuteNonQuery();
            }
        }
        private void PreguntasCalGen_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Muy de acuerdo");
            comboBox1.Items.Add("De acuerdo");
            comboBox1.Items.Add("Neutro");
            comboBox1.Items.Add("En desacuerdo");
            comboBox1.Items.Add("Muy en desacuerdo");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            InicioSesion inicioSesion = new InicioSesion();
            inicioSesion.Show();
            this.Close();
        }
        
    }
}


