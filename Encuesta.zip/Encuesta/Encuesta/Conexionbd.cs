﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Encuesta
{
    internal class Conexionbd
    {
        private static readonly string Query = "Data Source=KYO\\SQLEXPRESS;Initial Catalog=EncuestaBD;Integrated Security=True";
        private static SqlConnection connection;

        public static SqlConnection GetConnection()
        {
            if(connection == null)
            {
                connection= new SqlConnection(Query);
            }
            if (connection.State == System.Data.ConnectionState.Closed)
            {
                connection.Open();
            }
            return connection;
        }

        public static void CerrarConexion()
        {

            if (connection.State == System.Data.ConnectionState.Open)
            {
                connection.Close();

            }         
        }

    }
}
