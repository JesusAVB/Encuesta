﻿namespace Encuesta
{
    partial class PreguntasCalGen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Categoria = new Label();
            P = new Label();
            button1 = new Button();
            comboBox1 = new ComboBox();
            button2 = new Button();
            SuspendLayout();
            // 
            // Categoria
            // 
            Categoria.AutoSize = true;
            Categoria.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Categoria.Location = new Point(84, 71);
            Categoria.Name = "Categoria";
            Categoria.Size = new Size(95, 23);
            Categoria.TabIndex = 0;
            Categoria.Text = "Categoría";
            // 
            // P
            // 
            P.AutoSize = true;
            P.Font = new Font("Times New Roman", 10.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
            P.Location = new Point(90, 147);
            P.Name = "P";
            P.Size = new Size(74, 19);
            P.TabIndex = 1;
            P.Text = "Pregunta";
            // 
            // button1
            // 
            button1.Location = new Point(598, 338);
            button1.Name = "button1";
            button1.Size = new Size(156, 72);
            button1.TabIndex = 7;
            button1.Text = "Siguiente";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(309, 201);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(151, 28);
            comboBox1.TabIndex = 8;
            // 
            // button2
            // 
            button2.Location = new Point(84, 360);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 9;
            button2.Text = "Cerrar";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // PreguntasCalGen
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(comboBox1);
            Controls.Add(button1);
            Controls.Add(P);
            Controls.Add(Categoria);
            Name = "PreguntasCalGen";
            Text = "PreguntasCalGen";
            Load += PreguntasCalGen_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Categoria;
        private Label P;
        private Button button1;
        private ComboBox comboBox1;
        private Button button2;
    }
}
