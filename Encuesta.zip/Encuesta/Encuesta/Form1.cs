using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Encuesta
{
    public partial class Form1 : Form
    {
        private string cuentaUsuario;

        public Form1(string cuenta)
        {
            InitializeComponent();
            button2.Text = "Cerrar sesi�n";
            cuentaUsuario = cuenta;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Mostrar las categor�as en el DataGridView
            string consulta = "SELECT nombre as Categorias from Categorias";
            SqlDataAdapter adaptador = new SqlDataAdapter(consulta, Conexionbd.GetConnection());
            DataTable dt = new DataTable();
            adaptador.Fill(dt);
            dataGridView1.DataSource = dt;
            Conexionbd.CerrarConexion();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Pasar la cuenta del usuario a la ventana de preguntas
            PreguntasCalGen preguntasCalGen = new PreguntasCalGen(cuentaUsuario);
            preguntasCalGen.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Redirigir a la ventana de inicio de sesi�n
            InicioSesion form = new InicioSesion();
            form.Show();
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Acci�n cuando se hace clic en una celda (opcional)
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
            // Acci�n cuando se entra al GroupBox (opcional)
        }
    }
}
