﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Encuesta
{
    public partial class AdminEnc : Form
    {
        private string usuarioCuenta;

        public AdminEnc(string cuenta)
        {
            InitializeComponent();
            usuarioCuenta = cuenta;
            Cargar();  // Cargar las preguntas y categorías al inicio

            // Crear los Labels para almacenar los ID seleccionados (se pueden crear programáticamente)
            label5 = new Label();
            label5.Visible = false;
            this.Controls.Add(label5);

            label6 = new Label();
            label6.Visible = false;
            this.Controls.Add(label6);
        }

        // Función para cargar las preguntas y categorías en el DataGridView
        private void Cargar()
        {
            string pregun = "SELECT preguntas.pregunta AS Preguntas, categorias.nombre AS Categorias, preguntas.id AS PreguntaID, categorias.id AS CategoriaID " +
                            "FROM preguntas " +
                            "INNER JOIN categorias ON preguntas.id_categoria = categorias.id";
            SqlDataAdapter adaptador = new SqlDataAdapter(pregun, Conexionbd.GetConnection());
            DataTable dt = new DataTable();
            adaptador.Fill(dt);
            dataGridView1.DataSource = dt;
            Conexionbd.CerrarConexion();
        }

        // Agregar categoría
        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text.Trim() != "")
            {
                string query = "INSERT INTO categorias (nombre) VALUES (@nombre)";
                using (SqlCommand cmd = new SqlCommand(query, Conexionbd.GetConnection()))
                {
                    cmd.Parameters.AddWithValue("@nombre", textBox2.Text);
                    cmd.Parameters.AddWithValue("@id_usuario", usuarioCuenta);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Categoría agregada correctamente.","Agregar Categoiria",MessageBoxButtons.OK);
                }
                Conexionbd.CerrarConexion();
                textBox2.Clear();

                Cargar(); // Recargar las categorías y preguntas
            }
            else
            {
                MessageBox.Show("Por favor, ingrese un nombre para la categoría.","Agregar Categoria", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // Agregar pregunta a categoría
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() != "" && listBox2.SelectedItem != null)
            {
                string query = "INSERT INTO preguntas (pregunta, id_categoria) VALUES (@pregunta, @id_categoria)";
                using (SqlCommand cmd = new SqlCommand(query, Conexionbd.GetConnection()))
                {
                    cmd.Parameters.AddWithValue("@pregunta", textBox1.Text);
                    cmd.Parameters.AddWithValue("@id_categoria", (listBox2.SelectedItem as Categoria).Id);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Pregunta agregada correctamente.","Agregar pregunta");
                }
                Conexionbd.CerrarConexion();
                textBox1.Clear();
                Cargar(); // Recargar las preguntas y categorías
            }
            else
            {
                MessageBox.Show("Por favor, seleccione una categoría y/o ingrese una pregunta.","Agregar pregunta");
            }
        }

        // Buscar y cargar categorías en el ListBox
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string query = "SELECT id, nombre FROM categorias WHERE nombre LIKE @nombre";
            using (SqlCommand cmd = new SqlCommand(query, Conexionbd.GetConnection()))
            {
                cmd.Parameters.AddWithValue("@nombre", "%" + textBox2.Text + "%");
                SqlDataReader reader = cmd.ExecuteReader();
                listBox2.Items.Clear();
                while (reader.Read())
                {
                    listBox2.Items.Add(new Categoria
                    {
                        Id = (int)reader["id"],
                        Nombre = reader["nombre"].ToString()
                    });
                }
                Conexionbd.CerrarConexion();
            }
        }

        // Eliminar categoría
        private void button6_Click(object sender, EventArgs e)
        {
            if (int.TryParse(label6.Text, out int categoriaId))
            {
                // Verificar si hay preguntas asociadas a esta categoría
                string checkQuery = "SELECT COUNT(*) FROM preguntas WHERE id_categoria = @id_categoria";
                using (SqlCommand cmd = new SqlCommand(checkQuery, Conexionbd.GetConnection()))
                {
                    cmd.Parameters.AddWithValue("@id_categoria", categoriaId);
                    int count = (int)cmd.ExecuteScalar();
                    if (count > 0)
                    {
                        MessageBox.Show("No se puede eliminar la categoría porque tiene preguntas asociadas. Primero elimine las preguntas.","Ojo");
                        Conexionbd.CerrarConexion();
                        return; // Salir si hay preguntas asociadas
                    }
                }

                // Si no hay preguntas asociadas, proceder con la eliminación
                string deleteQuery = "DELETE FROM categorias WHERE id = @id_categoria";
                using (SqlCommand cmd = new SqlCommand(deleteQuery, Conexionbd.GetConnection()))
                {
                    cmd.Parameters.AddWithValue("@id_categoria", categoriaId);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Categoría eliminada correctamente.","Eliminar Categoria");
                }
                Conexionbd.CerrarConexion();
                Cargar(); // Recargar las preguntas y categorías
            }
            else
            {
                MessageBox.Show("Por favor, seleccione una categoría para eliminar.","Eliminar categoria");
            }
        }

        // Eliminar pregunta
        private void button5_Click(object sender, EventArgs e)
        {
            if (int.TryParse(label5.Text, out int preguntaId))
            {
                string deleteQuery = "DELETE FROM preguntas WHERE id = @id_pregunta";
                using (SqlCommand cmd = new SqlCommand(deleteQuery, Conexionbd.GetConnection()))
                {
                    cmd.Parameters.AddWithValue("@id_pregunta", preguntaId);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Pregunta eliminada correctamente.","Eliminar pregunta");
                }
                Conexionbd.CerrarConexion();
                Cargar(); // Recargar las preguntas y categorías
            }
            else
            {
                MessageBox.Show("Por favor, seleccione una pregunta para eliminar.","Eliminar pregunta");
            }
        }

        // Buscar y cargar preguntas en el ListBox
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string query = "SELECT id, pregunta FROM preguntas WHERE pregunta LIKE @pregunta";
            using (SqlCommand cmd = new SqlCommand(query, Conexionbd.GetConnection()))
            {
                cmd.Parameters.AddWithValue("@pregunta", "%" + textBox1.Text + "%");
                SqlDataReader reader = cmd.ExecuteReader();
                listBox1.Items.Clear();
                while (reader.Read())
                {
                    listBox1.Items.Add(new Pregunta
                    {
                        Id = (int)reader["id"],
                        Texto = reader["pregunta"].ToString()
                    });
                }
                Conexionbd.CerrarConexion();
            }
        }

        // Modificar categoría
        private void button4_Click(object sender, EventArgs e)
        {
            if (listBox2.SelectedItem != null && textBox1.Text.Trim() != "")
            {
                string query = "UPDATE categorias SET nombre = @nombre WHERE id = @id";
                using (SqlCommand cmd = new SqlCommand(query, Conexionbd.GetConnection()))
                {
                    var categoriaSeleccionada = listBox2.SelectedItem as Categoria;
                    cmd.Parameters.AddWithValue("@nombre", textBox1.Text);
                    cmd.Parameters.AddWithValue("@id", categoriaSeleccionada.Id);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Categoría modificada correctamente.","Categoria Modificada");
                }
                Conexionbd.CerrarConexion();
                Cargar(); // Recargar las categorías y preguntas
            }
            else
            {
                MessageBox.Show("Por favor, seleccione una categoría y/o ingrese un nuevo nombre.","Modificar Categoria");
            }
        }

        // Modificar pregunta
        private void button3_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null && textBox2.Text.Trim() != "")
            {
                string query = "UPDATE preguntas SET pregunta = @pregunta WHERE id = @id";
                using (SqlCommand cmd = new SqlCommand(query, Conexionbd.GetConnection()))
                {
                    var preguntaSeleccionada = listBox1.SelectedItem as Pregunta;
                    cmd.Parameters.AddWithValue("@pregunta", textBox2.Text);
                    cmd.Parameters.AddWithValue("@id", preguntaSeleccionada.Id);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Pregunta modificada correctamente.","Modificar pregunta");
                }
                Conexionbd.CerrarConexion();
                Cargar(); // Recargar las preguntas y categorías
            }
            else
            {
                MessageBox.Show("Por favor, seleccione una pregunta y/o ingrese un nuevo texto.","Modicar pregunta");
            }
        }

        // Evento para cuando se selecciona una categoría en el ListBox
        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox2.SelectedItem != null)
            {
                var categoriaSeleccionada = listBox2.SelectedItem as Categoria;
                textBox2.Text = categoriaSeleccionada.Nombre;
            }
        }

        // Evento para cuando se selecciona una pregunta en el ListBox
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                var preguntaSeleccionada = listBox1.SelectedItem as Pregunta;
                textBox1.Text = preguntaSeleccionada.Texto;
            }
        }

        // Estructuras de datos para representar Pregunta y Categoria
        public class Categoria
        {
            public int Id { get; set; }
            public string Nombre { get; set; }

            public override string ToString()
            {
                return Nombre;
            }
        }

        public class Pregunta
        {
            public int Id { get; set; }
            public string Texto { get; set; }

            public override string ToString()
            {
                return Texto;
            }
        }

        // Evento de clic en una celda del DataGridView
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)  // Verifica que se haya hecho clic en una fila válida
            {
                // Obtener los datos de la fila seleccionada
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                int preguntaId = Convert.ToInt32(row.Cells["PreguntaID"].Value);
                string preguntaTexto = row.Cells["Preguntas"].Value.ToString();
                int categoriaId = Convert.ToInt32(row.Cells["CategoriaID"].Value);
                string categoriaNombre = row.Cells["Categorias"].Value.ToString();

                // Mostrar los datos seleccionados en los TextBoxes para modificación
                textBox1.Text = preguntaTexto;
                textBox2.Text = categoriaNombre;

                // Guardar el ID de la pregunta y categoría seleccionada para usarla en la modificación
                label5.Text = preguntaId.ToString();
                label6.Text = categoriaId.ToString();
            }
        }
    }
}
