﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections.Immutable;
using System.Reflection.Metadata.Ecma335;

namespace Encuesta
{
    public partial class InicioSesion : Form
    {
        public InicioSesion()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string cuenta = textBox1.Text.Trim();
            string password = textBox2.Text.Trim();

            if (string.IsNullOrWhiteSpace(cuenta) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("¿Nos olvidamos de algo?","LLenado");
                return;
            }

            // Validar credenciales y obtener cuenta
            string query = "SELECT Cuenta, Rango FROM Usuario WHERE Cuenta = @cuenta AND Contraseña = @contraseña";
            using (SqlCommand cmd = new SqlCommand(query, Conexionbd.GetConnection()))
            {
                cmd.Parameters.AddWithValue("@cuenta", cuenta);
                cmd.Parameters.AddWithValue("@contraseña", password);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        string usuarioCuenta = reader["Cuenta"].ToString();
                        int rango = Convert.ToInt32(reader["Rango"]);

                        if (rango == 1) // Administrador
                        {
                            
                            Inter_Admin interAdmin = new Inter_Admin(usuarioCuenta);
                            reader.Close();
                            interAdmin.Show();
                            this.Hide();
                            
                        }
                        else // Usuario regular
                        {
                            Form1 form1 = new Form1(usuarioCuenta);
                            reader.Close();
                            form1.Show();
                            this.Hide();
                            ;
                        }
                        reader.Close();
                    }
                    else
                    {
                        MessageBox.Show("Usuario o contraseña incorrectos.");
                    }
                    
                }
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Redirigir a la ventana de registro de usuario
            RegistroUsuario registroUsuario = new RegistroUsuario(this);
            registroUsuario.Show();
            this.Hide();
        }
    }
}
