﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Encuesta
{
    public partial class RegistroUsuario : Form
    {
        private InicioSesion iniciosesion;
        public RegistroUsuario(InicioSesion form)
        {
            InitializeComponent();
            iniciosesion = form;
            
        }
        private bool UsuarioExiste(string cuenta)
        {
            bool existe = false;

            // Consulta SQL para verificar si la cuenta ya existe
            string query = "SELECT COUNT(*) FROM Usuario WHERE Cuenta = @Cuenta";
            SqlCommand command = new SqlCommand(query, Conexionbd.GetConnection());
                    
            // Agregar parámetro a la consulta
            command.Parameters.AddWithValue("@cuenta", cuenta);

            // Ejecutar la consulta y obtener el resultado
            int count = (int)command.ExecuteScalar();

            // Si el conteo es mayor que 0, la cuenta existe
            existe = count > 0;
                    
                
            

            return existe;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            int rango = 2;
            string cuenta = textBox1.Text.Trim();
            string contraseña = textBox2.Text.Trim();
            string Ccontraseña = textBox3.Text.Trim();
            //Botón de Registrarse
            string nUser = "INSERT INTO Usuario (Rango, Cuenta, Contraseña) VALUES (@rango,@cuenta,@contraseña)";
            SqlCommand Nuser = new SqlCommand(nUser, Conexionbd.GetConnection());
            

            if (string.IsNullOrEmpty(cuenta) || string.IsNullOrEmpty(contraseña)|| string.IsNullOrEmpty(Ccontraseña)) 
            {
                MessageBox.Show("Favor llenar los espacios.","Excepción",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }
            if (UsuarioExiste(cuenta))
            {
                MessageBox.Show("Este Usuario ya existe.","Error");
                return;
            }

            if (contraseña == Ccontraseña)
            {
                Nuser.Parameters.AddWithValue("@rango", rango);
                Nuser.Parameters.AddWithValue("@cuenta", cuenta);
                Nuser.Parameters.AddWithValue("@contraseña", contraseña);
                int rowsAffected = Nuser.ExecuteNonQuery();
                MessageBox.Show("Cuenta registrada exitosamente.","Registro");
                iniciosesion.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Favor de verificar que la Confirmación sea correcta.","Verificar",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            }
        }

    }
}
