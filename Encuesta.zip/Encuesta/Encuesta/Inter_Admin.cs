﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Encuesta
{
    public partial class Inter_Admin : Form
    {
        private string cuentaUsuario; // Cuenta del usuario que inició sesión

        public Inter_Admin(string cuenta)
        {
            InitializeComponent();
            cuentaUsuario = cuenta; // Guardar la cuenta del usuario
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Botón Admin Users
            AdminUsers adminUsers = new AdminUsers(cuentaUsuario);
            adminUsers.Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Admin Encuesta
            AdminEnc adminEnc = new AdminEnc(cuentaUsuario);
            adminEnc.Show();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Ir a la interfaz principal para usuarios
            Form1 form = new Form1(cuentaUsuario);
            form.Show();
            this.Close();
        }
    }
}
